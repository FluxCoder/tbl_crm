<?php

class AuthAPI extends CI_Controller {



    public function login(){
        echo "hello";
        // $email = $this->input->post('email');

    }


}